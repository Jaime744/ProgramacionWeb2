const express = require('express');
const router = express.Router();
const {
  getBooks,
  getBookById,
  createBook,
  updateBook,
  deleteBook,
  getStats,
} = require('../controllers/books.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');
const {
  createBookSchema,
  updateBookSchema,
  bookQuerySchema,
} = require('../schemas/validation');
const { validateRequest } = require('../middleware/error.middleware');

/**
 * @swagger
 * /api/books:
 *   get:
 *     summary: Listar libros con filtros y paginación
 *     tags: [Books]
 *     parameters:
 *       - in: query
 *         name: genre
 *         schema: { type: string }
 *       - in: query
 *         name: author
 *         schema: { type: string }
 *       - in: query
 *         name: available
 *         schema: { type: boolean }
 *       - in: query
 *         name: search
 *         schema: { type: string }
 *       - in: query
 *         name: page
 *         schema: { type: integer, default: 1 }
 *       - in: query
 *         name: limit
 *         schema: { type: integer, default: 10 }
 *     responses:
 *       200:
 *         description: Lista de libros paginada
 */
router.get('/', bookQuerySchema, validateRequest, getBooks);

/**
 * @swagger
 * /api/books/stats:
 *   get:
 *     summary: Estadísticas de libros más prestados y mejor valorados
 *     tags: [Books]
 *     responses:
 *       200:
 *         description: Estadísticas de la biblioteca
 */
router.get('/stats', getStats);

/**
 * @swagger
 * /api/books/{id}:
 *   get:
 *     summary: Obtener libro por ID
 *     tags: [Books]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: Datos del libro
 *       404:
 *         description: Libro no encontrado
 */
router.get('/:id', getBookById);

/**
 * @swagger
 * /api/books:
 *   post:
 *     summary: Crear nuevo libro
 *     tags: [Books]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       201:
 *         description: Libro creado
 *       403:
 *         description: Sin permisos
 */
router.post(
  '/',
  authenticate,
  authorize('LIBRARIAN', 'ADMIN'),
  createBookSchema,
  validateRequest,
  createBook
);

/**
 * @swagger
 * /api/books/{id}:
 *   put:
 *     summary: Actualizar libro
 *     tags: [Books]
 *     security:
 *       - bearerAuth: []
 */
router.put(
  '/:id',
  authenticate,
  authorize('LIBRARIAN', 'ADMIN'),
  updateBookSchema,
  validateRequest,
  updateBook
);

/**
 * @swagger
 * /api/books/{id}:
 *   delete:
 *     summary: Eliminar libro
 *     tags: [Books]
 *     security:
 *       - bearerAuth: []
 */
router.delete('/:id', authenticate, authorize('ADMIN'), deleteBook);

module.exports = router;
