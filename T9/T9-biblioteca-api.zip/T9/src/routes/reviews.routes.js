const express = require('express');
const router = express.Router({ mergeParams: true }); // para acceder a :id de books
const { getBookReviews, createReview, deleteReview } = require('../controllers/reviews.controller');
const { authenticate } = require('../middleware/auth.middleware');
const { createReviewSchema } = require('../schemas/validation');
const { validateRequest } = require('../middleware/error.middleware');

/**
 * @swagger
 * /api/books/{id}/reviews:
 *   get:
 *     summary: Obtener reseñas de un libro
 *     tags: [Reviews]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: Lista de reseñas
 */
router.get('/', getBookReviews);

/**
 * @swagger
 * /api/books/{id}/reviews:
 *   post:
 *     summary: Crear una reseña
 *     tags: [Reviews]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [rating]
 *             properties:
 *               rating: { type: integer, minimum: 1, maximum: 5 }
 *               comment: { type: string }
 */
router.post('/', authenticate, createReviewSchema, validateRequest, createReview);

module.exports = router;
