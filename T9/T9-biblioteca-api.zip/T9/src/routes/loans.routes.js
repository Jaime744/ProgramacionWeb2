const express = require('express');
const router = express.Router();
const { getMyLoans, getAllLoans, createLoan, returnLoan } = require('../controllers/loans.controller');
const { authenticate, authorize } = require('../middleware/auth.middleware');
const { createLoanSchema } = require('../schemas/validation');
const { validateRequest } = require('../middleware/error.middleware');

/**
 * @swagger
 * /api/loans:
 *   get:
 *     summary: Obtener mis préstamos
 *     tags: [Loans]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Lista de préstamos del usuario
 */
router.get('/', authenticate, getMyLoans);

/**
 * @swagger
 * /api/loans/all:
 *   get:
 *     summary: Obtener todos los préstamos (Librarian/Admin)
 *     tags: [Loans]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [ACTIVE, RETURNED, OVERDUE]
 */
router.get('/all', authenticate, authorize('LIBRARIAN', 'ADMIN'), getAllLoans);

/**
 * @swagger
 * /api/loans:
 *   post:
 *     summary: Solicitar un préstamo
 *     tags: [Loans]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [bookId]
 *             properties:
 *               bookId: { type: integer }
 */
router.post('/', authenticate, createLoanSchema, validateRequest, createLoan);

/**
 * @swagger
 * /api/loans/{id}/return:
 *   put:
 *     summary: Devolver un libro
 *     tags: [Loans]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 */
router.put('/:id/return', authenticate, returnLoan);

module.exports = router;
