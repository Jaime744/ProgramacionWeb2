const { Prisma } = require('@prisma/client');
const { validationResult } = require('express-validator');

/**
 * Middleware: maneja errores de validación de express-validator
 */
const validateRequest = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Datos de entrada inválidos',
      details: errors.array().map((e) => ({
        field: e.path,
        message: e.msg,
      })),
    });
  }
  next();
};

/**
 * Middleware: manejador global de errores
 */
const errorHandler = (err, req, res, next) => {
  console.error('❌ Error:', err);

  // Errores de Prisma
  if (err instanceof Prisma.PrismaClientKnownRequestError) {
    switch (err.code) {
      case 'P2002': {
        const field = err.meta?.target?.[0] || 'campo';
        return res.status(409).json({
          error: `Ya existe un registro con ese ${field}`,
          code: 'DUPLICATE_ENTRY',
        });
      }
      case 'P2025':
        return res.status(404).json({
          error: 'Registro no encontrado',
          code: 'NOT_FOUND',
        });
      case 'P2003':
        return res.status(400).json({
          error: 'Referencia a registro que no existe',
          code: 'FOREIGN_KEY_VIOLATION',
        });
      default:
        return res.status(400).json({
          error: 'Error de base de datos',
          code: err.code,
        });
    }
  }

  if (err instanceof Prisma.PrismaClientValidationError) {
    return res.status(400).json({
      error: 'Datos inválidos para la base de datos',
      code: 'VALIDATION_ERROR',
    });
  }

  // Errores con status definido
  if (err.status) {
    return res.status(err.status).json({ error: err.message });
  }

  // Error genérico
  res.status(500).json({
    error: 'Error interno del servidor',
    ...(process.env.NODE_ENV === 'development' && { details: err.message }),
  });
};

/**
 * Middleware: ruta no encontrada
 */
const notFound = (req, res) => {
  res.status(404).json({
    error: `Ruta ${req.method} ${req.path} no encontrada`,
  });
};

module.exports = { validateRequest, errorHandler, notFound };
