const prisma = require('../config/prisma');

/**
 * GET /api/books/:id/reviews
 */
const getBookReviews = async (req, res, next) => {
  try {
    const { id } = req.params;

    const book = await prisma.book.findUnique({ where: { id: parseInt(id) } });
    if (!book) {
      return res.status(404).json({ error: 'Libro no encontrado' });
    }

    const reviews = await prisma.review.findMany({
      where: { bookId: parseInt(id) },
      include: {
        user: { select: { id: true, name: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    const avgRating =
      reviews.length
        ? parseFloat((reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(2))
        : null;

    res.json({ data: reviews, total: reviews.length, avgRating });
  } catch (error) {
    next(error);
  }
};

/**
 * POST /api/books/:id/reviews
 */
const createReview = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { rating, comment } = req.body;
    const userId = req.user.id;
    const bookId = parseInt(id);

    const book = await prisma.book.findUnique({ where: { id: bookId } });
    if (!book) {
      return res.status(404).json({ error: 'Libro no encontrado' });
    }

    // Verificar que el usuario ha devuelto este libro (solo quienes lo leyeron pueden reseñar)
    const returnedLoan = await prisma.loan.findFirst({
      where: { userId, bookId, status: 'RETURNED' },
    });

    if (!returnedLoan) {
      return res.status(403).json({
        error: 'Solo puedes reseñar libros que hayas leído (préstamo devuelto)',
      });
    }

    const review = await prisma.review.create({
      data: { userId, bookId, rating: parseInt(rating), comment },
      include: {
        user: { select: { id: true, name: true } },
        book: { select: { id: true, title: true } },
      },
    });

    res.status(201).json({ message: 'Reseña creada con éxito', review });
  } catch (error) {
    next(error);
  }
};

/**
 * DELETE /api/reviews/:id
 */
const deleteReview = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const review = await prisma.review.findUnique({ where: { id: parseInt(id) } });

    if (!review) {
      return res.status(404).json({ error: 'Reseña no encontrada' });
    }

    // Solo el autor o un admin puede eliminar
    if (review.userId !== userId && req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'No tienes permiso para eliminar esta reseña' });
    }

    await prisma.review.delete({ where: { id: parseInt(id) } });

    res.json({ message: 'Reseña eliminada con éxito' });
  } catch (error) {
    next(error);
  }
};

module.exports = { getBookReviews, createReview, deleteReview };
