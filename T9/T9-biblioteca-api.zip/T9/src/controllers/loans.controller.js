const prisma = require('../config/prisma');

const MAX_ACTIVE_LOANS = 3;
const LOAN_DURATION_DAYS = 14;

/**
 * GET /api/loans — Mis préstamos
 */
const getMyLoans = async (req, res, next) => {
  try {
    const loans = await prisma.loan.findMany({
      where: { userId: req.user.id },
      include: {
        book: {
          select: { id: true, title: true, author: true, isbn: true, genre: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json({ data: loans, total: loans.length });
  } catch (error) {
    next(error);
  }
};

/**
 * GET /api/loans/all — Todos los préstamos (Librarian/Admin)
 */
const getAllLoans = async (req, res, next) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const take = parseInt(limit);

    const where = {};
    if (status) where.status = status;

    // Actualizar préstamos vencidos automáticamente
    await prisma.loan.updateMany({
      where: {
        status: 'ACTIVE',
        dueDate: { lt: new Date() },
      },
      data: { status: 'OVERDUE' },
    });

    const [loans, total] = await Promise.all([
      prisma.loan.findMany({
        where,
        skip,
        take,
        include: {
          user: { select: { id: true, name: true, email: true } },
          book: { select: { id: true, title: true, author: true, isbn: true } },
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.loan.count({ where }),
    ]);

    res.json({
      data: loans,
      pagination: {
        page: parseInt(page),
        limit: take,
        total,
        totalPages: Math.ceil(total / take),
      },
    });
  } catch (error) {
    next(error);
  }
};

/**
 * POST /api/loans — Solicitar préstamo
 */
const createLoan = async (req, res, next) => {
  try {
    const { bookId } = req.body;
    const userId = req.user.id;

    // Verificar que el libro existe
    const book = await prisma.book.findUnique({ where: { id: parseInt(bookId) } });
    if (!book) {
      return res.status(404).json({ error: 'Libro no encontrado' });
    }

    // Verificar disponibilidad
    if (book.available <= 0) {
      return res.status(409).json({
        error: 'No hay ejemplares disponibles de este libro',
        available: 0,
      });
    }

    // Verificar máximo préstamos activos del usuario
    const activeLoans = await prisma.loan.count({
      where: { userId, status: { in: ['ACTIVE', 'OVERDUE'] } },
    });

    if (activeLoans >= MAX_ACTIVE_LOANS) {
      return res.status(409).json({
        error: `No puedes tener más de ${MAX_ACTIVE_LOANS} préstamos activos`,
        activeLoans,
      });
    }

    // Verificar que no tiene ya este libro en préstamo activo
    const existingLoan = await prisma.loan.findFirst({
      where: { userId, bookId: parseInt(bookId), status: { in: ['ACTIVE', 'OVERDUE'] } },
    });

    if (existingLoan) {
      return res.status(409).json({
        error: 'Ya tienes este libro en préstamo',
        loanId: existingLoan.id,
      });
    }

    // Calcular fecha de devolución
    const loanDate = new Date();
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + LOAN_DURATION_DAYS);

    // Crear préstamo y decrementar available en una transacción
    const [loan] = await prisma.$transaction([
      prisma.loan.create({
        data: {
          userId,
          bookId: parseInt(bookId),
          loanDate,
          dueDate,
          status: 'ACTIVE',
        },
        include: {
          book: { select: { id: true, title: true, author: true, isbn: true } },
        },
      }),
      prisma.book.update({
        where: { id: parseInt(bookId) },
        data: { available: { decrement: 1 } },
      }),
    ]);

    res.status(201).json({
      message: 'Préstamo creado con éxito',
      loan,
      dueDate,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * PUT /api/loans/:id/return — Devolver libro
 */
const returnLoan = async (req, res, next) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const loan = await prisma.loan.findUnique({
      where: { id: parseInt(id) },
      include: { book: true },
    });

    if (!loan) {
      return res.status(404).json({ error: 'Préstamo no encontrado' });
    }

    // Solo el dueño o un admin/librarian puede devolver
    if (loan.userId !== userId && !['ADMIN', 'LIBRARIAN'].includes(req.user.role)) {
      return res.status(403).json({ error: 'No tienes permiso para devolver este préstamo' });
    }

    if (loan.status === 'RETURNED') {
      return res.status(409).json({ error: 'Este préstamo ya fue devuelto' });
    }

    const [updatedLoan] = await prisma.$transaction([
      prisma.loan.update({
        where: { id: parseInt(id) },
        data: { status: 'RETURNED', returnDate: new Date() },
        include: {
          book: { select: { id: true, title: true, author: true } },
        },
      }),
      prisma.book.update({
        where: { id: loan.bookId },
        data: { available: { increment: 1 } },
      }),
    ]);

    res.json({
      message: 'Libro devuelto con éxito',
      loan: updatedLoan,
    });
  } catch (error) {
    next(error);
  }
};

module.exports = { getMyLoans, getAllLoans, createLoan, returnLoan };
