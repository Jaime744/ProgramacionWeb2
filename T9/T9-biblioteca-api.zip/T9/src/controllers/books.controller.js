const prisma = require('../config/prisma');

/**
 * GET /api/books
 * Filtros: genre, author, available, search
 * Paginación: page, limit
 */
const getBooks = async (req, res, next) => {
  try {
    const {
      genre,
      author,
      available,
      search,
      page = 1,
      limit = 10,
    } = req.query;

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const take = parseInt(limit);

    // Construir filtros dinámicamente
    const where = {};

    if (genre) {
      where.genre = { contains: genre, mode: 'insensitive' };
    }

    if (author) {
      where.author = { contains: author, mode: 'insensitive' };
    }

    if (available === 'true') {
      where.available = { gt: 0 };
    } else if (available === 'false') {
      where.available = 0;
    }

    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { author: { contains: search, mode: 'insensitive' } },
        { isbn: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [books, total] = await Promise.all([
      prisma.book.findMany({
        where,
        skip,
        take,
        include: {
          _count: { select: { reviews: true, loans: true } },
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.book.count({ where }),
    ]);

    res.json({
      data: books,
      pagination: {
        page: parseInt(page),
        limit: take,
        total,
        totalPages: Math.ceil(total / take),
      },
    });
  } catch (error) {
    next(error);
  }
};

/**
 * GET /api/books/:id
 */
const getBookById = async (req, res, next) => {
  try {
    const { id } = req.params;

    const book = await prisma.book.findUnique({
      where: { id: parseInt(id) },
      include: {
        reviews: {
          include: {
            user: { select: { id: true, name: true } },
          },
          orderBy: { createdAt: 'desc' },
          take: 5,
        },
        _count: { select: { reviews: true, loans: true } },
      },
    });

    if (!book) {
      return res.status(404).json({ error: 'Libro no encontrado' });
    }

    // Calcular rating promedio
    const avgRating = book.reviews.length
      ? book.reviews.reduce((sum, r) => sum + r.rating, 0) / book.reviews.length
      : null;

    res.json({ ...book, avgRating: avgRating ? parseFloat(avgRating.toFixed(2)) : null });
  } catch (error) {
    next(error);
  }
};

/**
 * POST /api/books
 */
const createBook = async (req, res, next) => {
  try {
    const { isbn, title, author, genre, description, publishedYear, copies } = req.body;

    const copiesCount = copies || 1;

    const book = await prisma.book.create({
      data: {
        isbn,
        title,
        author,
        genre,
        description,
        publishedYear: parseInt(publishedYear),
        copies: copiesCount,
        available: copiesCount,
      },
    });

    res.status(201).json({ message: 'Libro creado con éxito', book });
  } catch (error) {
    next(error);
  }
};

/**
 * PUT /api/books/:id
 */
const updateBook = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { title, author, genre, description, publishedYear, copies } = req.body;

    // Verificar que el libro existe
    const existing = await prisma.book.findUnique({ where: { id: parseInt(id) } });
    if (!existing) {
      return res.status(404).json({ error: 'Libro no encontrado' });
    }

    const updateData = {};
    if (title !== undefined) updateData.title = title;
    if (author !== undefined) updateData.author = author;
    if (genre !== undefined) updateData.genre = genre;
    if (description !== undefined) updateData.description = description;
    if (publishedYear !== undefined) updateData.publishedYear = parseInt(publishedYear);

    // Si se actualiza copies, ajustar available proporcionalmente
    if (copies !== undefined) {
      const copiesInt = parseInt(copies);
      const loanedCopies = existing.copies - existing.available;
      const newAvailable = Math.max(0, copiesInt - loanedCopies);
      updateData.copies = copiesInt;
      updateData.available = newAvailable;
    }

    const book = await prisma.book.update({
      where: { id: parseInt(id) },
      data: updateData,
    });

    res.json({ message: 'Libro actualizado con éxito', book });
  } catch (error) {
    next(error);
  }
};

/**
 * DELETE /api/books/:id
 */
const deleteBook = async (req, res, next) => {
  try {
    const { id } = req.params;

    const book = await prisma.book.findUnique({ where: { id: parseInt(id) } });
    if (!book) {
      return res.status(404).json({ error: 'Libro no encontrado' });
    }

    // Verificar si hay préstamos activos
    const activeLoans = await prisma.loan.count({
      where: { bookId: parseInt(id), status: 'ACTIVE' },
    });

    if (activeLoans > 0) {
      return res.status(409).json({
        error: 'No se puede eliminar un libro con préstamos activos',
        activeLoans,
      });
    }

    await prisma.book.delete({ where: { id: parseInt(id) } });

    res.json({ message: 'Libro eliminado con éxito' });
  } catch (error) {
    next(error);
  }
};

/**
 * GET /api/books/stats - Libros más prestados y mejor valorados
 */
const getStats = async (req, res, next) => {
  try {
    const [mostLoaned, topRated] = await Promise.all([
      prisma.book.findMany({
        take: 5,
        include: { _count: { select: { loans: true } } },
        orderBy: { loans: { _count: 'desc' } },
        select: {
          id: true,
          title: true,
          author: true,
          genre: true,
          _count: { select: { loans: true } },
        },
      }),
      prisma.review.groupBy({
        by: ['bookId'],
        _avg: { rating: true },
        _count: { rating: true },
        having: { rating: { _count: { gte: 1 } } },
        orderBy: { _avg: { rating: 'desc' } },
        take: 5,
      }),
    ]);

    // Enriquecer top rated con datos del libro
    const topRatedWithBooks = await Promise.all(
      topRated.map(async (r) => {
        const book = await prisma.book.findUnique({
          where: { id: r.bookId },
          select: { id: true, title: true, author: true, genre: true },
        });
        return {
          ...book,
          avgRating: parseFloat(r._avg.rating.toFixed(2)),
          reviewCount: r._count.rating,
        };
      })
    );

    res.json({ mostLoaned, topRated: topRatedWithBooks });
  } catch (error) {
    next(error);
  }
};

module.exports = { getBooks, getBookById, createBook, updateBook, deleteBook, getStats };
