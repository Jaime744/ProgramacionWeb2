require('dotenv').config();
const express = require('express');
const cors = require('cors');
const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

const authRoutes = require('./routes/auth.routes');
const booksRoutes = require('./routes/books.routes');
const loansRoutes = require('./routes/loans.routes');
const reviewsRoutes = require('./routes/reviews.routes');
const { authenticate } = require('./middleware/auth.middleware');
const { errorHandler, notFound } = require('./middleware/error.middleware');

const app = express();

// ─── Middlewares globales ────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ─── Swagger ─────────────────────────────────────────────────────────────────
const swaggerOptions = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Biblioteca Digital API',
      version: '1.0.0',
      description: 'API REST para gestión de biblioteca digital con Supabase + Prisma',
    },
    servers: [{ url: `http://localhost:${process.env.PORT || 3000}` }],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
        },
      },
    },
  },
  apis: ['./src/routes/*.js'],
};

const swaggerSpec = swaggerJsdoc(swaggerOptions);
app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

// ─── Health check ─────────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    env: process.env.NODE_ENV,
  });
});

// ─── Rutas principales ────────────────────────────────────────────────────────
app.use('/api/auth', authRoutes);
app.use('/api/books', booksRoutes);

// Reviews anidadas bajo books
app.use('/api/books/:id/reviews', reviewsRoutes);

// Ruta independiente para eliminar reseña
app.delete('/api/reviews/:id', authenticate, async (req, res, next) => {
  const { deleteReview } = require('./controllers/reviews.controller');
  return deleteReview(req, res, next);
});

app.use('/api/loans', loansRoutes);

// ─── Error handlers ───────────────────────────────────────────────────────────
app.use(notFound);
app.use(errorHandler);

// ─── Iniciar servidor ─────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`\n🚀 Servidor corriendo en http://localhost:${PORT}`);
    console.log(`📚 Swagger UI en http://localhost:${PORT}/api/docs`);
    console.log(`🌍 Entorno: ${process.env.NODE_ENV || 'development'}\n`);
  });
}

module.exports = app;
