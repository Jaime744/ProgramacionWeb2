const { body, param, query } = require('express-validator');

// ─── AUTH ────────────────────────────────────────────────────────────────────

const registerSchema = [
  body('email')
    .isEmail()
    .withMessage('Email inválido')
    .normalizeEmail(),
  body('name')
    .trim()
    .notEmpty()
    .withMessage('El nombre es obligatorio')
    .isLength({ min: 2, max: 100 })
    .withMessage('El nombre debe tener entre 2 y 100 caracteres'),
  body('password')
    .isLength({ min: 6 })
    .withMessage('La contraseña debe tener al menos 6 caracteres'),
];

const loginSchema = [
  body('email')
    .isEmail()
    .withMessage('Email inválido')
    .normalizeEmail(),
  body('password')
    .notEmpty()
    .withMessage('La contraseña es obligatoria'),
];

// ─── BOOKS ───────────────────────────────────────────────────────────────────

const createBookSchema = [
  body('isbn')
    .trim()
    .notEmpty()
    .withMessage('El ISBN es obligatorio'),
  body('title')
    .trim()
    .notEmpty()
    .withMessage('El título es obligatorio'),
  body('author')
    .trim()
    .notEmpty()
    .withMessage('El autor es obligatorio'),
  body('genre')
    .trim()
    .notEmpty()
    .withMessage('El género es obligatorio'),
  body('publishedYear')
    .isInt({ min: 1000, max: new Date().getFullYear() })
    .withMessage('Año de publicación inválido'),
  body('copies')
    .optional()
    .isInt({ min: 1 })
    .withMessage('El número de copias debe ser un entero positivo'),
  body('description')
    .optional()
    .trim(),
];

const updateBookSchema = [
  body('title').optional().trim().notEmpty().withMessage('El título no puede estar vacío'),
  body('author').optional().trim().notEmpty().withMessage('El autor no puede estar vacío'),
  body('genre').optional().trim().notEmpty().withMessage('El género no puede estar vacío'),
  body('publishedYear')
    .optional()
    .isInt({ min: 1000, max: new Date().getFullYear() })
    .withMessage('Año de publicación inválido'),
  body('copies')
    .optional()
    .isInt({ min: 1 })
    .withMessage('El número de copias debe ser un entero positivo'),
  body('description').optional().trim(),
];

const bookQuerySchema = [
  query('genre').optional().trim(),
  query('author').optional().trim(),
  query('available')
    .optional()
    .isBoolean()
    .withMessage('available debe ser true o false'),
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('page debe ser un número positivo'),
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('limit debe estar entre 1 y 100'),
];

// ─── LOANS ───────────────────────────────────────────────────────────────────

const createLoanSchema = [
  body('bookId')
    .isInt({ min: 1 })
    .withMessage('bookId debe ser un número entero positivo'),
];

// ─── REVIEWS ─────────────────────────────────────────────────────────────────

const createReviewSchema = [
  body('rating')
    .isInt({ min: 1, max: 5 })
    .withMessage('El rating debe estar entre 1 y 5'),
  body('comment')
    .optional()
    .trim()
    .isLength({ max: 1000 })
    .withMessage('El comentario no puede superar los 1000 caracteres'),
];

module.exports = {
  registerSchema,
  loginSchema,
  createBookSchema,
  updateBookSchema,
  bookQuerySchema,
  createLoanSchema,
  createReviewSchema,
};
