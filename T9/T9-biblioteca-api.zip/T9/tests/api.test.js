const request = require('supertest');
const app = require('../src/app');
const prisma = require('../src/config/prisma');
const { hashPassword } = require('../src/utils/password');

// ─── Setup y Teardown ────────────────────────────────────────────────────────

let userToken, librarianToken, adminToken;
let testUserId, testBookId, testLoanId, testReviewId;

beforeAll(async () => {
  // Limpiar base de datos de test
  await prisma.review.deleteMany();
  await prisma.loan.deleteMany();
  await prisma.book.deleteMany();
  await prisma.user.deleteMany();

  const hash = await hashPassword('password123');

  // Crear usuarios de test
  const [user, librarian, admin] = await Promise.all([
    prisma.user.create({
      data: { email: 'user@test.com', name: 'Test User', password: hash, role: 'USER' },
    }),
    prisma.user.create({
      data: {
        email: 'librarian@test.com',
        name: 'Test Librarian',
        password: hash,
        role: 'LIBRARIAN',
      },
    }),
    prisma.user.create({
      data: { email: 'admin@test.com', name: 'Test Admin', password: hash, role: 'ADMIN' },
    }),
  ]);

  testUserId = user.id;

  // Obtener tokens via login
  const [userRes, libRes, adminRes] = await Promise.all([
    request(app).post('/api/auth/login').send({ email: 'user@test.com', password: 'password123' }),
    request(app)
      .post('/api/auth/login')
      .send({ email: 'librarian@test.com', password: 'password123' }),
    request(app)
      .post('/api/auth/login')
      .send({ email: 'admin@test.com', password: 'password123' }),
  ]);

  userToken = userRes.body.token;
  librarianToken = libRes.body.token;
  adminToken = adminRes.body.token;

  // Crear libro de prueba
  const book = await prisma.book.create({
    data: {
      isbn: '978-test-001',
      title: 'Libro de Prueba',
      author: 'Autor Test',
      genre: 'Test',
      publishedYear: 2024,
      copies: 3,
      available: 3,
    },
  });
  testBookId = book.id;
});

afterAll(async () => {
  await prisma.review.deleteMany();
  await prisma.loan.deleteMany();
  await prisma.book.deleteMany();
  await prisma.user.deleteMany();
  await prisma.$disconnect();
});

// ─── AUTH ────────────────────────────────────────────────────────────────────

describe('Auth', () => {
  describe('POST /api/auth/register', () => {
    it('debe registrar un nuevo usuario', async () => {
      const res = await request(app).post('/api/auth/register').send({
        email: 'nuevo@test.com',
        name: 'Nuevo Usuario',
        password: 'password123',
      });
      expect(res.status).toBe(201);
      expect(res.body).toHaveProperty('token');
      expect(res.body.user.email).toBe('nuevo@test.com');
      expect(res.body.user).not.toHaveProperty('password');
    });

    it('debe fallar con email duplicado', async () => {
      const res = await request(app).post('/api/auth/register').send({
        email: 'user@test.com',
        name: 'Duplicado',
        password: 'password123',
      });
      expect(res.status).toBe(409);
    });

    it('debe fallar con datos inválidos', async () => {
      const res = await request(app).post('/api/auth/register').send({
        email: 'no-es-un-email',
        name: '',
        password: '123',
      });
      expect(res.status).toBe(400);
      expect(res.body).toHaveProperty('details');
    });
  });

  describe('POST /api/auth/login', () => {
    it('debe iniciar sesión con credenciales correctas', async () => {
      const res = await request(app).post('/api/auth/login').send({
        email: 'user@test.com',
        password: 'password123',
      });
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('token');
    });

    it('debe fallar con contraseña incorrecta', async () => {
      const res = await request(app).post('/api/auth/login').send({
        email: 'user@test.com',
        password: 'wrongpassword',
      });
      expect(res.status).toBe(401);
    });

    it('debe fallar con email inexistente', async () => {
      const res = await request(app).post('/api/auth/login').send({
        email: 'noexiste@test.com',
        password: 'password123',
      });
      expect(res.status).toBe(401);
    });
  });

  describe('GET /api/auth/me', () => {
    it('debe devolver el perfil del usuario autenticado', async () => {
      const res = await request(app)
        .get('/api/auth/me')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(200);
      expect(res.body.user.email).toBe('user@test.com');
    });

    it('debe devolver 401 sin token', async () => {
      const res = await request(app).get('/api/auth/me');
      expect(res.status).toBe(401);
    });
  });
});

// ─── BOOKS ───────────────────────────────────────────────────────────────────

describe('Books', () => {
  describe('GET /api/books', () => {
    it('debe listar libros públicamente', async () => {
      const res = await request(app).get('/api/books');
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('data');
      expect(res.body).toHaveProperty('pagination');
      expect(Array.isArray(res.body.data)).toBe(true);
    });

    it('debe filtrar por género', async () => {
      const res = await request(app).get('/api/books?genre=Test');
      expect(res.status).toBe(200);
      expect(res.body.data.every((b) => b.genre.toLowerCase().includes('test'))).toBe(true);
    });

    it('debe paginar correctamente', async () => {
      const res = await request(app).get('/api/books?page=1&limit=1');
      expect(res.status).toBe(200);
      expect(res.body.data.length).toBeLessThanOrEqual(1);
      expect(res.body.pagination.limit).toBe(1);
    });
  });

  describe('GET /api/books/:id', () => {
    it('debe obtener un libro por ID', async () => {
      const res = await request(app).get(`/api/books/${testBookId}`);
      expect(res.status).toBe(200);
      expect(res.body.id).toBe(testBookId);
    });

    it('debe devolver 404 para ID inexistente', async () => {
      const res = await request(app).get('/api/books/99999');
      expect(res.status).toBe(404);
    });
  });

  describe('POST /api/books', () => {
    it('debe crear un libro si es LIBRARIAN', async () => {
      const res = await request(app)
        .post('/api/books')
        .set('Authorization', `Bearer ${librarianToken}`)
        .send({
          isbn: '978-test-002',
          title: 'Nuevo Libro Test',
          author: 'Autor Nuevo',
          genre: 'Ciencia Ficción',
          publishedYear: 2023,
          copies: 2,
        });
      expect(res.status).toBe(201);
      expect(res.body.book.title).toBe('Nuevo Libro Test');
    });

    it('debe rechazar creación a usuario normal (403)', async () => {
      const res = await request(app)
        .post('/api/books')
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          isbn: '978-test-003',
          title: 'No permitido',
          author: 'Test',
          genre: 'Test',
          publishedYear: 2023,
        });
      expect(res.status).toBe(403);
    });

    it('debe rechazar sin autenticación (401)', async () => {
      const res = await request(app).post('/api/books').send({
        isbn: '978-test-004',
        title: 'Sin token',
        author: 'Test',
        genre: 'Test',
        publishedYear: 2023,
      });
      expect(res.status).toBe(401);
    });
  });

  describe('DELETE /api/books/:id', () => {
    it('solo ADMIN puede eliminar libros', async () => {
      // Crear libro temporal para eliminar
      const book = await prisma.book.create({
        data: {
          isbn: '978-delete-test',
          title: 'Libro a eliminar',
          author: 'Test',
          genre: 'Test',
          publishedYear: 2020,
          copies: 1,
          available: 1,
        },
      });

      const res = await request(app)
        .delete(`/api/books/${book.id}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
    });

    it('LIBRARIAN no puede eliminar libros (403)', async () => {
      const res = await request(app)
        .delete(`/api/books/${testBookId}`)
        .set('Authorization', `Bearer ${librarianToken}`);
      expect(res.status).toBe(403);
    });
  });
});

// ─── LOANS ───────────────────────────────────────────────────────────────────

describe('Loans', () => {
  describe('POST /api/loans', () => {
    it('debe crear un préstamo', async () => {
      const res = await request(app)
        .post('/api/loans')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ bookId: testBookId });

      expect(res.status).toBe(201);
      expect(res.body.loan.bookId).toBe(testBookId);
      testLoanId = res.body.loan.id;
    });

    it('debe decrementar available del libro', async () => {
      const book = await prisma.book.findUnique({ where: { id: testBookId } });
      expect(book.available).toBe(2); // Empezaba en 3
    });

    it('no debe permitir préstamo duplicado activo', async () => {
      const res = await request(app)
        .post('/api/loans')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ bookId: testBookId });

      expect(res.status).toBe(409);
    });
  });

  describe('GET /api/loans', () => {
    it('debe devolver los préstamos del usuario autenticado', async () => {
      const res = await request(app)
        .get('/api/loans')
        .set('Authorization', `Bearer ${userToken}`);

      expect(res.status).toBe(200);
      expect(res.body.data.length).toBeGreaterThan(0);
      expect(res.body.data.every((l) => l.userId === testUserId)).toBe(true);
    });
  });

  describe('GET /api/loans/all', () => {
    it('LIBRARIAN puede ver todos los préstamos', async () => {
      const res = await request(app)
        .get('/api/loans/all')
        .set('Authorization', `Bearer ${librarianToken}`);
      expect(res.status).toBe(200);
    });

    it('usuario normal no puede ver todos los préstamos (403)', async () => {
      const res = await request(app)
        .get('/api/loans/all')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });
  });

  describe('PUT /api/loans/:id/return', () => {
    it('debe devolver el libro y restaurar available', async () => {
      const res = await request(app)
        .put(`/api/loans/${testLoanId}/return`)
        .set('Authorization', `Bearer ${userToken}`);

      expect(res.status).toBe(200);
      expect(res.body.loan.status).toBe('RETURNED');

      const book = await prisma.book.findUnique({ where: { id: testBookId } });
      expect(book.available).toBe(3); // Vuelve al valor original
    });

    it('no debe permitir devolver un préstamo ya devuelto', async () => {
      const res = await request(app)
        .put(`/api/loans/${testLoanId}/return`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(409);
    });
  });
});

// ─── REVIEWS ─────────────────────────────────────────────────────────────────

describe('Reviews', () => {
  describe('POST /api/books/:id/reviews', () => {
    it('debe crear una reseña si el usuario devolvió el libro', async () => {
      const res = await request(app)
        .post(`/api/books/${testBookId}/reviews`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ rating: 4, comment: 'Muy buen libro de prueba.' });

      expect(res.status).toBe(201);
      expect(res.body.review.rating).toBe(4);
      testReviewId = res.body.review.id;
    });

    it('no debe permitir reseñar sin haber devuelto el libro', async () => {
      // librarian nunca pidió este libro
      const res = await request(app)
        .post(`/api/books/${testBookId}/reviews`)
        .set('Authorization', `Bearer ${librarianToken}`)
        .send({ rating: 3 });

      expect(res.status).toBe(403);
    });

    it('debe fallar con rating inválido', async () => {
      const res = await request(app)
        .post(`/api/books/${testBookId}/reviews`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ rating: 10 });

      expect(res.status).toBe(400);
    });
  });

  describe('GET /api/books/:id/reviews', () => {
    it('debe listar reseñas públicamente', async () => {
      const res = await request(app).get(`/api/books/${testBookId}/reviews`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body.data)).toBe(true);
      expect(res.body).toHaveProperty('avgRating');
    });
  });

  describe('DELETE /api/reviews/:id', () => {
    it('debe eliminar la propia reseña', async () => {
      const res = await request(app)
        .delete(`/api/reviews/${testReviewId}`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(200);
    });

    it('debe devolver 404 para reseña inexistente', async () => {
      const res = await request(app)
        .delete('/api/reviews/99999')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(404);
    });
  });
});
