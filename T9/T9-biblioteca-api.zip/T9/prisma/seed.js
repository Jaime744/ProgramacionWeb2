const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Sembrando datos de prueba...');

  // Limpiar tablas en orden correcto
  await prisma.review.deleteMany();
  await prisma.loan.deleteMany();
  await prisma.book.deleteMany();
  await prisma.user.deleteMany();

  // Crear usuarios
  const passwordHash = await bcrypt.hash('password123', 10);

  const admin = await prisma.user.create({
    data: {
      email: 'admin@biblioteca.com',
      name: 'Admin Principal',
      password: passwordHash,
      role: 'ADMIN',
    },
  });

  const librarian = await prisma.user.create({
    data: {
      email: 'bibliotecario@biblioteca.com',
      name: 'María García',
      password: passwordHash,
      role: 'LIBRARIAN',
    },
  });

  const user1 = await prisma.user.create({
    data: {
      email: 'juan@example.com',
      name: 'Juan Pérez',
      password: passwordHash,
      role: 'USER',
    },
  });

  const user2 = await prisma.user.create({
    data: {
      email: 'ana@example.com',
      name: 'Ana Martínez',
      password: passwordHash,
      role: 'USER',
    },
  });

  console.log('✅ Usuarios creados');

  // Crear libros
  const books = await Promise.all([
    prisma.book.create({
      data: {
        isbn: '978-0-7432-7356-5',
        title: 'El Gran Gatsby',
        author: 'F. Scott Fitzgerald',
        genre: 'Ficción Clásica',
        description: 'Una historia sobre el sueño americano en los años 20.',
        publishedYear: 1925,
        copies: 3,
        available: 3,
      },
    }),
    prisma.book.create({
      data: {
        isbn: '978-0-06-112008-4',
        title: 'Matar a un Ruiseñor',
        author: 'Harper Lee',
        genre: 'Ficción Clásica',
        description: 'Un abogado defiende a un hombre negro en el sur de Estados Unidos.',
        publishedYear: 1960,
        copies: 2,
        available: 2,
      },
    }),
    prisma.book.create({
      data: {
        isbn: '978-0-14-028329-7',
        title: '1984',
        author: 'George Orwell',
        genre: 'Distopía',
        description: 'Una sociedad totalitaria donde el Gran Hermano todo lo ve.',
        publishedYear: 1949,
        copies: 4,
        available: 4,
      },
    }),
    prisma.book.create({
      data: {
        isbn: '978-84-376-0494-7',
        title: 'Cien Años de Soledad',
        author: 'Gabriel García Márquez',
        genre: 'Realismo Mágico',
        description: 'La historia de la familia Buendía en el mítico pueblo de Macondo.',
        publishedYear: 1967,
        copies: 3,
        available: 3,
      },
    }),
    prisma.book.create({
      data: {
        isbn: '978-0-7432-7357-2',
        title: 'El Señor de los Anillos',
        author: 'J.R.R. Tolkien',
        genre: 'Fantasía',
        description: 'La épica lucha por el anillo del poder en la Tierra Media.',
        publishedYear: 1954,
        copies: 5,
        available: 4,
      },
    }),
    prisma.book.create({
      data: {
        isbn: '978-84-450-7669-8',
        title: 'Don Quijote de la Mancha',
        author: 'Miguel de Cervantes',
        genre: 'Clásico Español',
        description: 'Las aventuras del ingenioso hidalgo Don Quijote.',
        publishedYear: 1605,
        copies: 2,
        available: 2,
      },
    }),
  ]);

  console.log('✅ Libros creados');

  // Crear algunos préstamos
  const loanDate = new Date();
  const dueDate = new Date();
  dueDate.setDate(dueDate.getDate() + 14);

  const pastLoanDate = new Date();
  pastLoanDate.setDate(pastLoanDate.getDate() - 20);
  const pastDueDate = new Date();
  pastDueDate.setDate(pastDueDate.getDate() - 6);

  await prisma.loan.create({
    data: {
      userId: user1.id,
      bookId: books[4].id, // El Señor de los Anillos
      loanDate,
      dueDate,
      status: 'ACTIVE',
    },
  });

  // Actualizar available del libro prestado
  await prisma.book.update({
    where: { id: books[4].id },
    data: { available: { decrement: 1 } },
  });

  // Préstamo devuelto (para que user1 pueda hacer reseña)
  await prisma.loan.create({
    data: {
      userId: user1.id,
      bookId: books[0].id, // El Gran Gatsby
      loanDate: pastLoanDate,
      dueDate: pastDueDate,
      returnDate: new Date(pastDueDate.getTime() - 2 * 24 * 60 * 60 * 1000),
      status: 'RETURNED',
    },
  });

  console.log('✅ Préstamos creados');

  // Crear una reseña
  await prisma.review.create({
    data: {
      userId: user1.id,
      bookId: books[0].id,
      rating: 5,
      comment: 'Una obra maestra absoluta. La prosa de Fitzgerald es simplemente bella.',
    },
  });

  console.log('✅ Reseñas creadas');
  console.log('\n🎉 Seed completado con éxito!');
  console.log('\n📋 Credenciales de prueba:');
  console.log('  Admin:        admin@biblioteca.com / password123');
  console.log('  Bibliotecario: bibliotecario@biblioteca.com / password123');
  console.log('  Usuario 1:    juan@example.com / password123');
  console.log('  Usuario 2:    ana@example.com / password123');
}

main()
  .catch((e) => {
    console.error('❌ Error en seed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
