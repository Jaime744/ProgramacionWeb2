# T9 — Biblioteca Digital API

API REST para gestión de biblioteca digital con **Supabase + Prisma + Express**.

## Stack

- **Node.js** + **Express** — servidor HTTP
- **Prisma ORM** — acceso a base de datos con tipado
- **Supabase** — PostgreSQL gestionado en la nube
- **JWT** — autenticación sin estado
- **bcryptjs** — hash de contraseñas
- **Swagger UI** — documentación interactiva
- **Jest + Supertest** — tests de integración

---

## Configuración inicial

### 1. Crear proyecto en Supabase

1. Ve a [supabase.com](https://supabase.com) y crea una cuenta
2. Crea un nuevo proyecto
3. Ve a **Settings → Database → Connection string**
4. Copia las URLs `URI` (con y sin pgbouncer)

### 2. Instalar dependencias

```bash
cd ejercicios/T9
npm install
```

### 3. Configurar variables de entorno

```bash
cp .env.example .env
```

Edita `.env` con tus credenciales de Supabase:

```env
DATABASE_URL="postgresql://postgres:[PASSWORD]@db.[REF].supabase.co:5432/postgres?pgbouncer=true"
DIRECT_URL="postgresql://postgres:[PASSWORD]@db.[REF].supabase.co:5432/postgres"
JWT_SECRET="tu_secreto_seguro_aqui"
```

### 4. Ejecutar migraciones

```bash
npx prisma migrate dev --name init
```

### 5. Sembrar datos de prueba (opcional)

```bash
npm run db:seed
```

Credenciales creadas por el seed:

| Rol | Email | Contraseña |
|-----|-------|-----------|
| ADMIN | admin@biblioteca.com | password123 |
| LIBRARIAN | bibliotecario@biblioteca.com | password123 |
| USER | juan@example.com | password123 |
| USER | ana@example.com | password123 |

### 6. Iniciar servidor

```bash
npm run dev
```

---

## Endpoints

### Auth

| Método | Ruta | Descripción | Acceso |
|--------|------|-------------|--------|
| POST | `/api/auth/register` | Registrar usuario | Público |
| POST | `/api/auth/login` | Iniciar sesión | Público |
| GET | `/api/auth/me` | Ver perfil propio | Autenticado |

### Books

| Método | Ruta | Descripción | Acceso |
|--------|------|-------------|--------|
| GET | `/api/books` | Listar libros (filtros + paginación) | Público |
| GET | `/api/books/stats` | Estadísticas | Público |
| GET | `/api/books/:id` | Detalle de libro | Público |
| POST | `/api/books` | Crear libro | Librarian/Admin |
| PUT | `/api/books/:id` | Actualizar libro | Librarian/Admin |
| DELETE | `/api/books/:id` | Eliminar libro | Admin |

#### Filtros disponibles en GET /api/books

```
?genre=Ficción          # filtrar por género
?author=Orwell          # filtrar por autor
?available=true         # solo con ejemplares disponibles
?search=gatsby          # búsqueda en título, autor, ISBN
?page=1&limit=10        # paginación
```

### Loans

| Método | Ruta | Descripción | Acceso |
|--------|------|-------------|--------|
| GET | `/api/loans` | Mis préstamos | Autenticado |
| GET | `/api/loans/all` | Todos los préstamos | Librarian/Admin |
| POST | `/api/loans` | Solicitar préstamo | Autenticado |
| PUT | `/api/loans/:id/return` | Devolver libro | Autenticado |

### Reviews

| Método | Ruta | Descripción | Acceso |
|--------|------|-------------|--------|
| GET | `/api/books/:id/reviews` | Reseñas de un libro | Público |
| POST | `/api/books/:id/reviews` | Crear reseña | Autenticado |
| DELETE | `/api/reviews/:id` | Eliminar reseña | Autenticado |

---

## Reglas de negocio

- **Préstamos**: máximo 3 activos por usuario, duración 14 días
- **Disponibilidad**: `available` se decrementa al prestar y se incrementa al devolver
- **Reseñas**: solo usuarios que hayan devuelto el libro pueden reseñar; máximo una por libro
- **Roles**: USER < LIBRARIAN < ADMIN

---

## Scripts

```bash
npm run dev          # Servidor con hot-reload
npm start            # Servidor en producción
npm run db:studio    # Abrir Prisma Studio (GUI de BD)
npm run db:migrate   # Crear migración
npm run db:push      # Sincronizar schema sin migración
npm run db:seed      # Sembrar datos de prueba
npm test             # Ejecutar tests
```

---

## Documentación Swagger

Con el servidor corriendo, visita:

```
http://localhost:3000/api/docs
```

---

## Estructura del proyecto

```
T9/
├── prisma/
│   ├── schema.prisma      # Modelos y relaciones
│   └── seed.js            # Datos de prueba
├── src/
│   ├── app.js             # Configuración Express + rutas
│   ├── config/
│   │   └── prisma.js      # Cliente Prisma singleton
│   ├── controllers/
│   │   ├── auth.controller.js
│   │   ├── books.controller.js
│   │   ├── loans.controller.js
│   │   └── reviews.controller.js
│   ├── middleware/
│   │   ├── auth.middleware.js    # JWT + autorización por rol
│   │   └── error.middleware.js  # Validaciones + errores Prisma
│   ├── routes/
│   │   ├── auth.routes.js
│   │   ├── books.routes.js
│   │   ├── loans.routes.js
│   │   └── reviews.routes.js
│   ├── schemas/
│   │   └── validation.js   # Schemas express-validator
│   └── utils/
│       ├── jwt.js           # generateToken / verifyToken
│       └── password.js      # hashPassword / comparePassword
├── tests/
│   ├── api.http             # Tests con REST Client (VS Code)
│   └── api.test.js          # Tests Jest + Supertest
├── .env.example
├── .gitignore
├── package.json
└── README.md
```
